cond(A)
