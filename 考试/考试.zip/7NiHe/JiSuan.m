syms x
y=6.2236*x^(2.02);
x=6;
py=subs(y);
vpa(py,8)

